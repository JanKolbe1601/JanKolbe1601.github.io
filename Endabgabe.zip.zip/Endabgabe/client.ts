namespace newYear {

    let buttonExists: boolean = false;
// wurden buttons schon erstellt
    export interface CanvasElement {
        name: string;
        type: string;
        x: string;
        y: string;
        color: string;
        particles: string;
    }

    // Interface zum abspeichern des canvas elementes 

    export let rebuildArray: CanvasElement[];

    // array wird mit daten von der datenbank

    export function insert(_name: string): void {
        let query: string = "command=insert";
        query += "&Name=" + _name;
        for (let i: number = 0; i < allFireworks.length; i++) {
            
            let Element: CanvasElement = {
                name: _name,
                type: allFireworks[i].type,
                x: allFireworks[i].x.toString(),
                y: allFireworks[i].y.toString(),
                color: allFireworks[i].color.toString(),
                particles: allFireworks[i].particles.toString()
            }
            //werte werden für jedes element abgefragt
            query += "&Type=" + Element.type + "&X=" + Element.x + "&Y=" + Element.y + "&Color=" + Element.color + "&Particles=" + Element.particles;
        } // und in den query geschrieben
        sendRequest(query, handleInsertResponse);
        console.log("query:", query);
        // query wir an server duch funktion send request geschickt
    }

    function sendRequest(_query: string, _callback: EventListener): void {
        let xhr: XMLHttpRequest = new XMLHttpRequest();
        xhr.open("GET", serverAddress + "?" + _query, true);
        xhr.addEventListener("readystatechange", _callback);
        xhr.send();
    }

    //versendet die daten an der server 

    function handleInsertResponse(_event: ProgressEvent): void {
        let xhr: XMLHttpRequest = (<XMLHttpRequest>_event.target);
        if (xhr.readyState == XMLHttpRequest.DONE) {
            alert(xhr.response);
        }
    }
    //Antwort aufs abspeichern (wenn du fertig bist alert mit der response)

    export function find(): void {
        let query: string = "command=find";
        sendRequest(query, handleFindResponse);
    } 
    // abgespeicherte bilder auf server suchen 

   function handleFindResponse(_event: ProgressEvent): void {
        let xhr: XMLHttpRequest = (<XMLHttpRequest>_event.target);
        if (xhr.readyState == XMLHttpRequest.DONE) {
            rebuildArray = JSON.parse(xhr.response);
            console.log(rebuildArray);
            // wenn die suche durch ist, speicher mir gefundene objecte in unser rebuildarray
            if (buttonExists == false) {
                for (let i = 0; i < rebuildArray.length; i++) {
                    let button = document.createElement("button");
                    button.innerText = "Bild" + i.toString();
                    button.addEventListener("click", rebuildCanvas);
                    button.setAttribute("id", i.toString());
                    document.getElementById("output").appendChild(button);
                    buttonExists = true;
                    // für jedes canvas element wird ein button erstelt mit click event und id
                }
            }
        }
    } 

}