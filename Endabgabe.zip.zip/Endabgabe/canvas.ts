namespace newYear {
    document.addEventListener("DOMContentLoaded", init);

    export let crc: CanvasRenderingContext2D;
    let canvas: HTMLCanvasElement;
    let imageData: ImageData;
    export let allFireworks: Firework[] = [];
    export let serverAddress: string = "https://fireworkofjan.herokuapp.com/"; 

    // Elemente werden angelegt

    function init(): void {
        canvas = document.getElementsByTagName("canvas")[1];
        crc = canvas.getContext("2d");
        drawBackground();
        imageData = crc.getImageData(0, 0, canvas.width, canvas.height);
        //firework.draw()
        let saveButton: HTMLButtonElement = <HTMLButtonElement>document.getElementById("save");
        saveButton.addEventListener("click", saveCanvas);
        find();
        update();
    }
    // canvas element aus Html wird in der variable Canvas abgespeichert
    // hintergrund wird aufgerufen und abgespeichert
    // save button funlktion wird angelegt
    // Funktion find und update werden aufgerufen

    function drawBackground(): void {
        crc.rect(0, 0, 500, 400);
        crc.fillStyle = "rgb(51, 35, 86)";
        crc.fill();
        for (let i: number = 0; i < 40; i++) {
            let x : number = getRandomInt(500);
            let y : number = getRandomInt(400);
            let star: Path2D = new Path2D();
            star.arc(x,y,1,0,10);
            crc.fillStyle = "white"
            crc.fill(star);
        }
    }

    // Backgound wird erstellt

    function saveCanvas(): void {
        let bildName: string = prompt("wie möchten sie ihr Bild nennen?");
        insert(bildName);
    }
    // Bildname wird eigentlich abgespeichert aber funkt nit
    // ruft funktion insert auf 

    
    function getRandomInt(max:number) {
        return Math.floor(Math.random() * Math.floor(max));
    }
    //  random zahl wird generiert 

    export function overlay(){
        crc.rect(0, 0, 500, 400);
        crc.fillStyle = "rgba(0,0,0,0.5)";
        crc.fill();
        crc.font = "30px Arial";
        crc.fillStyle = "white"
        crc.fillText("click any point to set origin",70 , 200);
    }
    // overlay fürs plazieren wird gemalt

    export function getCoordinates(x:number, y:number){
        console.log("placeItHere")
        if (currentStyle == "line"){
        let firework: Firework = new Firework(pickedColor, numberOfParticles, x, y - 120);
        allFireworks.push(firework);
        }
        if (currentStyle == "arc"){
        let firework: Firework = new FireworkTriangle(pickedColor, numberOfParticles, x, y - 120);
        allFireworks.push(firework);
        }
        waitForOrigin = false;
        //crc.clearRect()
        update();
    }
    // wenn user feuerwerk plaziert wird der x und y wert wird übergeben + 
    //die der Typ des Feuerwerks abgefragt und anschleißend erstellt
    // boolean wird wieder auf false gesetzt = overlay verschwindet 

    export function rebuildCanvas(_e: MouseEvent): void {
        console.log("rebuild");
        let id = this.id;
        let xCoordinates: string = rebuildArray[id].x;
        let yCoordinates: string = rebuildArray[id].y;
        let type: string = rebuildArray[id].type;
        let color: string = rebuildArray[id].color;
        let particles: string = rebuildArray[id].particles;

        // über id wird abgefragt welcher button geclickt wurde 
        // alle werte über das event werden abgespeichert

        for (let i: number = 0; i <= allFireworks.length; i++) {
            allFireworks.splice(0, allFireworks.length);
        }
        for (let i: number = 0; i < xCoordinates.length; i++) {
            let NewObject: CanvasElement = {
                type: type[i],
                x: xCoordinates[i],
                y: yCoordinates[i],
                color: color[i],
                particles: particles[i],
                name: ""
            }
            if (NewObject.type == "line"){
                let firework: Firework = new Firework(NewObject.color, parseInt(NewObject.particles), parseInt(NewObject.x), parseInt(NewObject.y));
                allFireworks.push(firework);
            } else {
                let firework: Firework = new FireworkTriangle(NewObject.color, parseInt(NewObject.particles), parseInt(NewObject.x), parseInt(NewObject.y));
                allFireworks.push(firework);
            }
    }
}

// Canvas wird gelert 
// Gespeichertes Feuerwerk wird nach und nach abgerufen und wieder erstellt

    function update():void {
        if (waitForOrigin) { return; }
        window.setTimeout(update, 1000 / 30);
        crc.clearRect(0, 0, canvas.width, canvas.height);
        crc.putImageData(imageData, 0, 0);
        for (let i: number = 0; i < allFireworks.length; i++) {
            allFireworks[i].update();
            //console.log(allFireworks[i]);
        }
    }
}
// ruf die Funktion update 30 mal die sekunde auf 
// löscht alles gemalte was drin ist und updated die position und malt neu 